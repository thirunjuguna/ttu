<?php

namespace ttu\Http\Controllers;

use Illuminate\Http\Request;

class Excel extends Controller
{
    //
}
